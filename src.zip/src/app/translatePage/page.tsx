// components
import { TranslateUI, Footer} from "../../components";

// sections

export default function Campaign() {
  return (
    <>
      <TranslateUI/>
      <Footer/>
    </>
  );
}
